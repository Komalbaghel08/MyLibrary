from django.apps import AppConfig


class MylibraryAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mylibrary_app'
